sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.biplab.interaction.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);